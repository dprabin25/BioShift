# BioShift case study: input data

Longitudinal data from one stable periodontal site (sample IDs `1_stable_0` to `1_stable_12`), sampled every two months for 12 months (7 time points).

## Files

| File | Contents |
|---|---|
| `CaseStudy_1stable_input_matrix.csv` | All three data types in one table: 7 samples × 433 elements, column names prefixed `Cell|`, `Protein|` or `Microbe|` |
| `CaseStudy_1stable_cells.csv` | Cell fractions from FARDEEP deconvolution of bulk RNA-seq (62 cell types) |
| `CaseStudy_1stable_proteins_log10.csv` | Cytokine levels, log10(concentration + 1) (64 analytes) |
| `CaseStudy_1stable_microbes_counts.csv` | Microbial read counts (307 taxa) |
| `CaseStudy_1stable_regression_results.csv` | Slope, R², p value, BH q value, direction and BioShift selection for every element |
| `regression.py` | Script that reproduces the regression results from the input matrix |

`Month` (0, 2, 4, 6, 8, 10, 12) is the predictor in every file.

## Regression

Each element was fitted separately with least-squares linear regression on month.

- **Tested:** 170 elements with non-constant values (19 cells, 63 proteins, 88 microbes). The other 263 are constant across the 7 samples and were not tested.
- **Selected:** 27 elements had p < 0.05 and form the BioShift input (`BioShift_input = Yes`): 7 proteins, 1 cell type and 19 microbes.
- **Multiple testing:** none remain significant after Benjamini–Hochberg correction (minimum q = 0.31). The unadjusted threshold was used as an exploratory criterion to select elements.

The B-cell trend comes from column `PD_B`, the periodontitis-derived B-cell signature. Column `B` is zero in all seven samples.

## Sources

Microbial composition: NCBI SRA BioProject PRJNA725874 (Duran-Pinedo et al. 2021, BMC Biol 19:240).
Host transcriptome: NCBI SRA BioProject PRJNA770647 (Duran-Pinedo et al. 2025, Microbiome 13:119).
Cytokines: Biomarkers of Periodontal Disease Progression study, ClinicalTrials.gov NCT01489839 (Teles et al. 2025, J Clin Periodontol 52:40–55).
