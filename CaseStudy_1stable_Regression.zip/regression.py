"""Reproduce the case-study trend analysis.

Usage: python regression.py CaseStudy_1stable_input_matrix.csv
Writes regression_results.csv with slope, R2, p value, BH q value and direction per element.
"""
import sys

import numpy as np
import pandas as pd
from scipy import stats


def bh(p):
    p = np.asarray(p, dtype=float)
    n = len(p)
    order = np.argsort(p)
    q = p[order] * n / np.arange(1, n + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.minimum(q, 1)
    return out


df = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else "CaseStudy_1stable_input_matrix.csv", index_col=0)
t = df.pop("Month").to_numpy(dtype=float)

rows = []
for col in df.columns:
    modality, element = col.split("|", 1)
    y = df[col].to_numpy(dtype=float)
    if np.ptp(y) == 0:
        continue  # constant across samples: not tested
    r = stats.linregress(t, y)
    rows.append([modality, element, r.slope, r.rvalue ** 2, r.pvalue])

res = pd.DataFrame(rows, columns=["Modality", "Element", "Slope_per_month", "R2", "P_value"])
res["BH_q"] = bh(res["P_value"])
res["Direction"] = np.where(
    res["P_value"] < 0.05,
    np.where(res["Slope_per_month"] > 0, "Increase", "Decrease"),
    "No significant trend",
)
res = res.sort_values("P_value")
res.to_csv("regression_results.csv", index=False)

print(f"Tested: {len(res)} ({res.Modality.value_counts().to_dict()})")
print(f"p < 0.05: {(res.P_value < 0.05).sum()}; BH q < 0.05: {(res.BH_q < 0.05).sum()}")
